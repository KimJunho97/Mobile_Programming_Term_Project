package com.example.androidtermproject;

public class Clothes {

    public String user_id;
    public String name_str;
    public String category_str;
    public String detail_str;
    public String color_str;
    public String style_str;

    public Clothes()
    {

    }

    public Clothes(String user_id, String name_str, String category_str, String detail_str, String color_str, String style_str)
    {
        this.user_id = user_id;
        this.name_str = name_str;
        this.category_str = category_str;
        this.detail_str = detail_str;
        this.color_str = color_str;
        this.style_str = style_str;
    }


}


