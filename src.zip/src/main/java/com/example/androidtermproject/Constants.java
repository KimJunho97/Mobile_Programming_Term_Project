package com.example.androidtermproject;

public class Constants {

    public Integer[] mImages = {

            R.drawable.cloth_pants, R.drawable.cloth_pants2,
            R.drawable.cloth_pants3, R.drawable.cloth_pants4,
            R.drawable.cloth_pants5, R.drawable.cloth_pants6,
            R.drawable.cloth_pants7, R.drawable.cloth_pants8
    };
}
