package com.example.androidtermproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;


public class RegisterPictureActivity extends AppCompatActivity {

    private Uri mImageCaptureUri;
    private static final int PICK_FROM_CAMERA = 0;
    private static final int PICK_FROM_ALBUM = 1;
    private static final int CROP_FROM_IMAGE = 2;
    private ImageView iv_UserPhoto;
    private String absolutePath;
    private int CAMERA_REQUEST_CODE = 0;



    ///////////////////////////////////사진 앨범에서 선택해서 올리기
    public void getPhoto() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, 1);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getPhoto();
            }
        }
    }


    /////////////////////////////////////////////////기본 on create
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_pictuer);

        final Spinner category1 = (Spinner) findViewById(R.id.category1);
        final Spinner category2 = (Spinner) findViewById(R.id.category2);
        final Spinner color = (Spinner) findViewById(R.id.color);
        final Spinner style = (Spinner) findViewById(R.id.style);

        final String[] cloth_category1 = getResources().getStringArray(R.array.cloth_category1);
        final String[] cloth_top = getResources().getStringArray(R.array.cloth_top);
        final String[] cloth_pants = getResources().getStringArray(R.array.cloth_pants);
        final String[] shoes = getResources().getStringArray(R.array.shoes);
        final String[] colors = getResources().getStringArray(R.array.color);
        final String[] styles = getResources().getStringArray(R.array.style);
        final String[] not_selected = getResources().getStringArray(R.array.not_selected);


        final LinearLayout linearLayout = (LinearLayout) findViewById(R.id.select_picture);
        linearLayout.setVisibility(View.INVISIBLE);

        Button register_picture = (Button) findViewById(R.id.register_picture);


        register_picture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                FrameLayout frameLayout = (FrameLayout) findViewById(R.id.container);


            }
        });


        ArrayAdapter<String> category1_adapter = new ArrayAdapter<String>(getBaseContext(), R.layout.support_simple_spinner_dropdown_item, cloth_category1);
        category1_adapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        category1.setAdapter(category1_adapter);
        category1.setPrompt("옷중류1");

        category1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                String top_str = "상의";
                String pants_str = "하의";
                String shoes_str = "신발";
                String not_selected_str = "(선택)";

                if (top_str.equals(category1.getSelectedItem().toString())) {
                    //상의 일 경우
                    ArrayAdapter<String> cloth_top_adapter = new ArrayAdapter<String>(getBaseContext(), R.layout.support_simple_spinner_dropdown_item, cloth_top);
                    cloth_top_adapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
                    category2.setAdapter(cloth_top_adapter);
                } else if (pants_str.equals(category1.getSelectedItem().toString())) {
                    //하의 일 경우
                    ArrayAdapter<String> cloth_pants_adapter = new ArrayAdapter<String>(getBaseContext(), R.layout.support_simple_spinner_dropdown_item, cloth_pants);
                    cloth_pants_adapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
                    category2.setAdapter(cloth_pants_adapter);
                } else if (shoes_str.equals(category1.getSelectedItem().toString())) {
                    //신발 일 경우
                    ArrayAdapter<String> shoes_adapter = new ArrayAdapter<String>(getBaseContext(), R.layout.support_simple_spinner_dropdown_item, shoes);
                    shoes_adapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
                    category2.setAdapter(shoes_adapter);
                } else if (not_selected_str.equals(category1.getSelectedItem().toString())) {
                    //아무것도 선택이 안되어 있을 경우
                    ArrayAdapter<String> not_selected_adapter = new ArrayAdapter<String>(getBaseContext(), R.layout.support_simple_spinner_dropdown_item, not_selected);
                    not_selected_adapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
                    category2.setAdapter(not_selected_adapter);
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        //색깔
        ArrayAdapter<String> color_adapter = new ArrayAdapter<String>(getBaseContext(), R.layout.support_simple_spinner_dropdown_item, colors);
        color_adapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        color.setAdapter(color_adapter);
        color.setPrompt("색깔");

        //스타일
        ArrayAdapter<String> style_adapter = new ArrayAdapter<String>(getBaseContext(), R.layout.support_simple_spinner_dropdown_item, styles);
        style_adapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        style.setAdapter(style_adapter);
        style.setPrompt("스타일");

        Button btn_register = (Button) findViewById(R.id.register_picture);

        ///////////////////////////////////사진 등록 버튼
        btn_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                linearLayout.setVisibility(View.VISIBLE);

            }
        });

        //////////////////////////////// 사진 촬영 버튼




        ////////////////////////////////앨범 선택 버튼

        Button btn_album = (Button) findViewById(R.id.btn_album);

        btn_album.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                linearLayout.setVisibility(View.INVISIBLE);
                getPhoto();
            }
        });


        //////////////////////////////////// 취소 버튼
        Button btn_cancel = (Button) findViewById(R.id.btn_cancel);

        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                linearLayout.setVisibility(View.INVISIBLE);
            }
        });

    }
    ////////////////////////////////여기 까지가 onCreate

    ///////////////////////////////////on activityResult
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK && data != null) {
            Uri selectedImage = data.getData();
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), selectedImage);
                ImageView imageView = (ImageView) findViewById(R.id.picture_cloth);
                imageView.setImageBitmap(bitmap);

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

}
